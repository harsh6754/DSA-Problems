// C++ implementation of brute
// force solution.
#include <bits/stdc++.h>
using namespace std;

// Function to check if the given
// number has repeated digit or not
int repeated_digit(int n)
{
	unordered_set<int> s;

	// Traversing through each digit
	while(n != 0)
	{
		int d = n % 10;

		// if the digit is present
		// more than once in the
		// number
		if(s.find(d) != s.end())
		{
			// return 0 if the number
			// has repeated digit
			return 0;
		}
		s.insert(d);
		n = n / 10;
	}
	// return 1 if the number has 
	// no repeated digit
	return 1;
}

// Function to find total number
// in the given range which has
// no repeated digit
int calculate(int n,int m)
{
	int answer = 0;

	// Traversing through the range
	for(int i = n; i < m + 1; ++i)
	{

		// Add 1 to the answer if i has
		// no repeated digit else 0
		answer = answer + repeated_digit(i);
	}

	return answer ;
}

// Driver Code
int main()
{
	int n;
    cin>>n;

    int m;
    cin>>m;

	// Calling the calculate
	cout << calculate(n, m);
	return 0;
}
